package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import model.RecentOrderBookAsk;
import model.RecentOrderBookBid;
import model.RecentTrades;

public class MainController implements Initializable {

	/* For recent Trades */
	@FXML
	TableView<RecentTrades> tblID;
	@FXML
	TableColumn<RecentTrades, String> amount;
	@FXML
	TableColumn<RecentTrades, String> price;
	@FXML
	TableColumn<RecentTrades, String> time;

	/* For live orderbook-Bid */
	@FXML
	TableView<RecentOrderBookBid> tblBidID;
	@FXML
	TableColumn<RecentOrderBookBid, String> bid;
	@FXML
	TableColumn<RecentOrderBookBid, String> bidAmount;
	@FXML
	TableColumn<RecentOrderBookBid, String> bidValue;

	/* For live orderbook-Ask */
	@FXML
	TableView<RecentOrderBookAsk> tblAskID;
	@FXML
	TableColumn<RecentOrderBookAsk, String> ask;
	@FXML
	TableColumn<RecentOrderBookAsk, String> askAmount;
	@FXML
	TableColumn<RecentOrderBookAsk, String> askValue;

	// Live Recent Trades data
	final ObservableList<RecentTrades> recentTrades = FXCollections.observableArrayList(
			new RecentTrades("342.45", "654.12", "12/07/2017"), new RecentTrades("3453.45", "9876", "02/08/2017"),
			new RecentTrades("5621.45", "4532", "12/07/2014"), new RecentTrades("342.45", "654.12", "12/07/2017"),
			new RecentTrades("3453.45", "9876", "02/08/2017"), new RecentTrades("5621.45", "4532", "12/07/2016"),
			new RecentTrades("342.45", "654.12", "12/07/2017"), new RecentTrades("3453.45", "9876", "02/08/2017"),
			new RecentTrades("5621.45", "4532", "12/07/2016"), new RecentTrades("342.45", "654.12", "12/07/2017"),
			new RecentTrades("3453.45", "9876", "02/08/2017"), new RecentTrades("5621.45", "4532", "12/07/2016")

	);

	// Live Bid Data
	final ObservableList<RecentOrderBookBid> recentBids = FXCollections.observableArrayList(
			new RecentOrderBookBid("7380.11", "654.12", "22655.00"),
			new RecentOrderBookBid("7380.10", "9876", "22655.00"),
			new RecentOrderBookBid("7380.01", "4532", "22655.00"),
			new RecentOrderBookBid("7380.60", "654.12", "22655.00"),
			new RecentOrderBookBid("7380.01", "9876", "22655.00"),
			new RecentOrderBookBid("7389.11", "4532", "22655.00"),
			new RecentOrderBookBid("7360.11", "654.12", "22655.00"),
			new RecentOrderBookBid("7380.11", "9876", "22655.00"),
			new RecentOrderBookBid("7380.11", "4532", "22655.00"),
			new RecentOrderBookBid("7350.11", "9876", "22655.00"),
			new RecentOrderBookBid("7380.11", "4532", "22655.00"),
			new RecentOrderBookBid("7380.11", "654.12", "22655.00"),
			new RecentOrderBookBid("7332.11", "9876", "22655.00"),
			new RecentOrderBookBid("7380.11", "4532", "22655.00"));

	// Live ask Data
	final ObservableList<RecentOrderBookAsk> recentAsks = FXCollections.observableArrayList(
			new RecentOrderBookAsk("7392.25", "0.7179500", "5307.62"),
			new RecentOrderBookAsk("7392.89", "5.0009500", "4377.62"),
			new RecentOrderBookAsk("7393.10", "4.6179500", "5307.62"),
			new RecentOrderBookAsk("7393.30", "3.7179500", "22655.00"),
			new RecentOrderBookAsk("7393.23", "0.4174300", "22655.00"),
			new RecentOrderBookAsk("7392.08", "0.7179500", "22655.00"),
			new RecentOrderBookAsk("7391.00", "1.3179500", "22655.00"),
			new RecentOrderBookAsk("7394.00", "0.7179500", "22655.00"),
			new RecentOrderBookAsk("7392.25", "0.7179500", "22655.00"),
			new RecentOrderBookAsk("7393.24", "4.7179500", "22655.00"),
			new RecentOrderBookAsk("7390.00", "0.7179500", "22655.00"),
			new RecentOrderBookAsk("7391.01", "2.7179500", "22655.00"),
			new RecentOrderBookAsk("7394.33", "0.7179500", "22655.00"),
			new RecentOrderBookAsk("7395.30", "9.7179500", "22655.00"));

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// Setting it for RecentTrades
		amount.setCellValueFactory(new PropertyValueFactory<RecentTrades, String>("amount"));
		price.setCellValueFactory(new PropertyValueFactory<RecentTrades, String>("price"));
		time.setCellValueFactory(new PropertyValueFactory<RecentTrades, String>("time"));
		tblID.setItems(recentTrades);

		// Setting it for RecentOrderBookBid
		bid.setCellValueFactory(new PropertyValueFactory<RecentOrderBookBid, String>("bid"));
		bidAmount.setCellValueFactory(new PropertyValueFactory<RecentOrderBookBid, String>("bidAmount"));
		bidValue.setCellValueFactory(new PropertyValueFactory<RecentOrderBookBid, String>("bidValue"));
		tblBidID.setItems(recentBids);

		// Setting it for RecentOrderBookAsk
		ask.setCellValueFactory(new PropertyValueFactory<RecentOrderBookAsk, String>("ask"));
		askAmount.setCellValueFactory(new PropertyValueFactory<RecentOrderBookAsk, String>("askAmount"));
		askValue.setCellValueFactory(new PropertyValueFactory<RecentOrderBookAsk, String>("askValue"));

		tblAskID.setItems(recentAsks);
	}

}
