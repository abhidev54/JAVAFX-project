package controller;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainView extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		try {
			AnchorPane page = (AnchorPane) FXMLLoader.load(MainView.class.getResource("MainController.fxml"));
			Scene scene = new Scene(page);
			scene.getStylesheets().add("style.css");
			primaryStage.setScene(scene);
			primaryStage.setTitle("Bitcoin Trading Application");
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

   public static void main(String[] args) {
	   Application.launch(MainView.class,(java.lang.String[]) null);
   }

}
