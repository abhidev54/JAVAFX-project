package model;



public class RecentTrades {
	private String amount;
	private String price;
	private String time;

	public RecentTrades(String string, String string2, String string3) {
		super();
		this.amount = string;
		this.price = string2;
		this.time = string3;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

}
