package model;

public class RecentOrderBookBid {
	private String bid;
	private String bidAmount;
	private String bidValue;

	public RecentOrderBookBid(String bid, String bidAmount, String bidValue) {
		super();
		this.bid = bid;
		this.bidAmount = bidAmount;
		this.bidValue = bidValue;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getBidAmount() {
		return bidAmount;
	}

	public void setBidAmount(String bidAmount) {
		this.bidAmount = bidAmount;
	}

	public String getBidValue() {
		return bidValue;
	}

	public void setBidValue(String bidValue) {
		this.bidValue = bidValue;
	}




}
