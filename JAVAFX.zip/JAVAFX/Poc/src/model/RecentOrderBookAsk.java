package model;

public class RecentOrderBookAsk {
	private String ask;
	private String askAmount;
	private String askValue;

	public RecentOrderBookAsk(String ask, String askAmount, String askValue) {
		super();
		this.ask = ask;
		this.askAmount = askAmount;
		this.askValue = askValue;
	}

	public String getAsk() {
		return ask;
	}

	public void setAsk(String ask) {
		this.ask = ask;
	}

	public String getAskAmount() {
		return askAmount;
	}

	public void setAskAmount(String askAmount) {
		this.askAmount = askAmount;
	}

	public String getAskValue() {
		return askValue;
	}

	public void setAskValue(String askValue) {
		this.askValue = askValue;
	}



}
